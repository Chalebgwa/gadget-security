import 'package:flutter/material.dart';
import 'package:gsec/models/user.dart';

class UserProvider extends ChangeNotifier {
  List<User> _users = [];
  List<User> get users => generateUsers();

  Future<bool> addUser(String name, String surname, String email,
      String password, String id) async {
    // todo : check if the id number or email already exists before saving to the database
    User _user = User(userId: id, name: name, surname: surname, email: email);
    _users.add(_user);
    return true;
  }

  List<User> generateUsers() {
    for (var i = 0; i < 10; i++) {
      User _user = new User(name: "user-$i", userId: "$i");
      _users.add(_user);
    }
    return _users;
  }
}
