import 'package:flutter/widgets.dart';
import 'package:gsec/models/chat.dart';
import 'package:provider/provider.dart';

class InboxProvider with ChangeNotifier {

  List<Conversation> _conversations = [];
  List<Conversation> get conversations => _conversations;

  Conversation fetchConvoById(String groupChatId) {
    return _conversations.firstWhere((c) => c.id == groupChatId,orElse: ()=> null);
  }
}

class Conversation with ChangeNotifier {
  final String id;

  Conversation(this.id);

  List<Message> _messages = [];
  List<Message> get messages => _messages;

  void addMessage(Message message) {
    _messages.insert(0, message);
    notifyListeners();
  }
}

class ChatListener extends StreamProvider<Chat> {
  
}
