import 'dart:async';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:gsec/models/user.dart';

enum AuthState {
  LOADING,
  SIGNED_IN,
  SIGNED_OUT,
}

class Auth extends ChangeNotifier {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final GoogleSignIn googleSignIn = GoogleSignIn();
  //
  AuthState _state = AuthState.SIGNED_OUT;
  //
  User _currentUser;

  //
  AuthState get state => _state;

  //
  User get currentUser => _currentUser;

  //
  Future<bool> register(String name, String surname, String id, String email,
      String password) async {
    return true;
  }

  //

  Future<String> signInWithGoogle() async {
    final GoogleSignInAccount googleSignInAccount = await googleSignIn.signIn();
    final GoogleSignInAuthentication googleSignInAuthentication =
        await googleSignInAccount.authentication;

    final AuthCredential credential = GoogleAuthProvider.getCredential(
      accessToken: googleSignInAuthentication.accessToken,
      idToken: googleSignInAuthentication.idToken,
    );

    final AuthResult authResult = await _auth.signInWithCredential(credential);
    final FirebaseUser user = authResult.user;

    assert(!user.isAnonymous);
    assert(await user.getIdToken() != null);

    final FirebaseUser currentUser = await _auth.currentUser();
    assert(user.uid == currentUser.uid);

    return 'signInWithGoogle succeeded: $user';
  }

  void signOutGoogle() async {
    await googleSignIn.signOut();

    print("User Sign Out");
  }

  void updateUser(
      {name,
      city,
      email,
      idNumber,
      phone,
      userId,
      middlename,
      surname,
      country,
      imageUrl}) {
    _currentUser = new User(
        name: name,
        city: city,
        email: email,
        idNumber: idNumber,
        phone: phone,
        middlename: middlename,
        country: country,
        userId: userId,
        imageUrl: imageUrl);
    notifyListeners();
  }

  //
  void signIn() {
    _state = AuthState.LOADING;

    Timer(Duration(seconds: 3), () {
      _state = AuthState.SIGNED_IN;
      _currentUser = User(
        city: "Francitown",
        country: "Botswana",
        email: "TestPilot@gmail.com",
        idNumber: "734561234",
        name: "Test",
        phone: "77147912",
        userId: "001",
        middlename: "Timothy",
        surname: "Pilot",
        imageUrl: null,
      );

      notifyListeners();
    });
  }

  void signOut() {
    _state = AuthState.SIGNED_OUT;
    notifyListeners();
  }
}
