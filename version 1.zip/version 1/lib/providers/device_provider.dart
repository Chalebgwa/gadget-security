import 'package:flutter/widgets.dart';
import 'package:gsec/models/device.dart';
import 'package:gsec/models/user.dart';

class DeviceProvider extends ChangeNotifier {
  List<Device> _devices = [];

  List<Device> get devices => _devices;

  void setPrimaryDevice(userId,deviceInfo){

  }

  void addDevice(Device device) {
    _devices.add(device);
    notifyListeners();
  }

  Future<bool> createDevice(Device device) async {
    Map _deviceMap = {
      'ownerId': device.ownerId,
      'serial': device.serialNumber,
      'name': device.name
    };
    // todo: call set data on firebase

    return true;
  }

  Future<bool> deleteDevice(Device device) async {

  }

  void editDevice(){

  }

  void transfer(Device device,User user){

  }

  void removeDevice(Device device) {
    _devices.remove(device);
    notifyListeners();
  }
}
