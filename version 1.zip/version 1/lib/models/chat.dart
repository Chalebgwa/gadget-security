import 'package:gsec/models/user.dart';

enum Type { GIF, VIDEO, VOICENOTE, IMAGE, TEXT }

class Chat {
  final User peer;
  final User user;
  final List<Message> messages;
  Chat({this.peer, this.user, this.messages});

}

class Message {
  final String content;
  final Type type;
  final String timestamp;
  final bool to;

  Message({this.content, this.type, this.timestamp, this.to});

  factory Message.fromMap(Map map) {
    return Message(
        content: map['content'] ?? null,
        timestamp: map['timestamp'] ?? null,
        to: map['to'],
        type: map['type']);
  }
}
