class User {
  final String name;
  final String city;
  final String country;
  final String email;
  final String phone;
  final String idNumber;
  final String userId;
  final String middlename;
  final String surname;
  final String imageUrl;

  User({
    this.imageUrl,
    this.middlename,
    this.surname,
    this.name,
    this.city,
    this.country,
    this.email,
    this.phone,
    this.idNumber,
    this.userId,
  });

  Future<User> getUser(String userId) async {
    // todo : connect to firebase and fetch user data
    return User();
  }

  Stream<List<User>> fetchUsers(String userId) async* {
    // todo: connect to db and fetch map
    List<Map> usersMap = [];
    List<User> users = usersMap.map((doc) => User.fromMap(doc));
    yield users;
  }

  factory User.fromMap(Map map) {
    return User(
      name: map['name'] ?? null,
      surname: map['surname'] ?? null,
      email: map['email'] ?? null,
      city: map['city'] ?? null,
      country: map['country'] ?? null,
      idNumber: map['idNumber'] ?? null,
      imageUrl: map['imageUrl'] ?? null,
      middlename: map['middlename'] ?? null,
      phone: map['phone'] ?? null,
      userId: map['userId'] ?? null,
    );
  }
}
