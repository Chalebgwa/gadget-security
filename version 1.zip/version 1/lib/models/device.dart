import 'package:flutter/widgets.dart';

class Device {
  final String ownerId;
  final String id;
  final String name;
  final String serialNumber;
  final String IMEI1;
  final String IMEI2;
  final Color color;
  final DateTime year;

  Device(
      {this.ownerId,
      this.id,
      this.name,
      this.serialNumber,
      this.IMEI1,
      this.IMEI2,
      this.color,
      this.year});

}
