import 'package:flutter/material.dart';
import 'package:gsec/providers/auth_provider.dart';
import 'package:gsec/providers/device_provider.dart';
import 'package:gsec/root.dart';


import 'package:provider/provider.dart';

import 'views/authenticated/profile/edit_profile.dart';
import 'views/authenticated/settings.dart';
import 'views/authentication/authentication.dart';
import 'views/qr_athentication/scanner.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      child: MaterialApp(
        debugShowCheckedModeBanner: false,
        
        routes: {
          "/": (context) => Root(),
          "/auth": (context) => Athentication(),
          "/editProfile": (context) => EditProfile(),
          "/scanner": (context) => Scanner(),
          "/settings": (context) => Settings()
        },
        title: 'Gadget Security',
      ),
      providers: <SingleChildCloneableWidget>[
        ChangeNotifierProvider(
          builder: (BuildContext context) => Auth(),
        ),
        ChangeNotifierProvider(
          builder: (BuildContext context) => DeviceProvider(),
        ),
        ChangeNotifierProvider(
          builder: (BuildContext context) => InboxProvider(),
        ),
        ChangeNotifierProvider(
          builder: (BuildContext context) => UserProvider(),
        ),
      ],
    );
  }
}
