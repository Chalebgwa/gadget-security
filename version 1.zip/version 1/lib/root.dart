import 'package:flutter/material.dart';
import 'package:gsec/page.dart';
import 'package:gsec/providers/auth_providers/auth_providers.dart';
import 'package:gsec/views/dashboard.dart';
import 'package:provider/provider.dart';

class Root extends StatefulWidget {
  @override
  _RootState createState() => _RootState();
}

class _RootState extends State<Root> {
  Auth _auth;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _auth = Provider.of<Auth>(context);
  }

  @override
  Widget build(BuildContext context) {
    switch (_auth.state) {
      case AuthState.SIGNED_OUT:
        return Page(
          child: DashBoard(),
        );

      case AuthState.SIGNED_IN:
        return Page(
          child: DashBoard(),
        );
      case AuthState.LOADING:
        return Center(
          child: Text("Insert loading screen"),
        );
      default:
    }
  }
}
