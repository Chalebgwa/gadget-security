import 'dart:ui';

import 'package:carousel_pro/carousel_pro.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter/widgets.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:gsec/providers/auth_providers/auth_providers.dart';
import 'package:gsec/views/authenticated/inbox.dart';
import 'package:gsec/views/authenticated/profile/profile.dart';
import 'package:provider/provider.dart';

class Page extends StatefulWidget {
  final EdgeInsetsGeometry margin;
  final Color backgroundColor;
  final double opacity;
  final Widget child;
  final Image image;
  final bool showDrawer;

  const Page({
    Key key,
    this.margin,
    this.backgroundColor,
    this.opacity,
    this.image,
    this.child,
    this.showDrawer = true,
  }) : super(key: key);

  @override
  _PageState createState() => _PageState();
}

class _PageState extends State<Page> {
  Auth _auth;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _auth = Provider.of<Auth>(context);
  }

  void signOut() {
    Navigator.pop(context);
    _auth.signOut();
  }

  void navigateToSignUp() {
    Navigator.popAndPushNamed(context, "/auth");
  }

  void showExitPop() {}

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () {
        if (Navigator.canPop(context)) {
          Navigator.pop(context);
        } else {
          SystemNavigator.pop();
        }
      },
      child: SafeArea(
        child: Stack(
          fit: StackFit.expand,
          children: <Widget>[
            buildBackGroundImage(),
            Scaffold(
              appBar: AppBar(
                actionsIconTheme: IconThemeData(color: Colors.black, size: 45),
                centerTitle: true,
                title:
                    _auth.state == AuthState.SIGNED_OUT ? null : buildActions(),
                leading: null,
                automaticallyImplyLeading: false,
                backgroundColor: Colors.transparent,
                elevation: 0,
                iconTheme: IconThemeData(color: Colors.white),
              ),
              endDrawer: widget.showDrawer ? buildDrawer() : null,
              backgroundColor: Colors.transparent,
              body: widget.child,
            ),
          ],
        ),
      ),
    );
  }

  Widget normalRow(String text, Color color) {
    return Padding(
      padding: EdgeInsets.all(12.5),
      child: Container(
        decoration: BoxDecoration(
            color: color,
            borderRadius: const BorderRadius.all(const Radius.circular(10.0))),
        child: Center(
          child: Text(
            text,
            style: const TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.bold,
                fontSize: 12.5),
          ),
        ),
      ),
    );
  }

  Widget buildActions() {
    return IconTheme(
      data: IconThemeData(color: Colors.black.withOpacity(.5)),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          buildStackedIconButton(
            6,
            FontAwesomeIcons.solidBell,
            () {},
          ),
          buildStackedIconButton(
            4,
            FontAwesomeIcons.solidUser,
            navigateToProfile,
          ),
          buildStackedIconButton(
            0,
            FontAwesomeIcons.solidEnvelope,
            navigateToInbox,
          ),
        ],
      ),
    );
  }

  Stack buildStackedIconButton(int data, IconData icon, VoidCallback callback) {
    return Stack(
      children: <Widget>[
        IconButton(
          icon: Icon(icon),
          onPressed: callback,
        ),
        Positioned(
          left: 2,
          top: 4,
          child: data > 0
              ? CircleAvatar(
                  radius: 10,
                  child: Text(
                    "$data",
                    style: TextStyle(fontSize: 10),
                  ),
                )
              : Container(),
        ),
      ],
    );
  }

  Widget buildBackGroundImage() {
    Size s = MediaQuery.of(context).size;

    return Container(
        height: s.height,
        width: s.width,
        child: Image.asset(
          "assets/giphy.gif",
          fit: BoxFit.fitHeight,
        ));
  }

  Widget buildLogo() {
    return Image.asset(
      "assets/logo.png",
    );
  }

  void navigateToQR() {
    Navigator.popAndPushNamed(context, "/scanner");
  }

  void navigateToSettings() {
    Navigator.popAndPushNamed(context, "/settings");
  }

  SizedBox buildAdView() {
    return SizedBox(
      height: 200,
      //width: double.infinity,
      child: Carousel(
        autoplayDuration: Duration(seconds: 5),
        noRadiusForIndicator: true,
        overlayShadow: false,
        showIndicator: false,
        animationCurve: Curves.easeOutBack,
        images: [
          Image.asset("assets/ad1.jpeg"),
          Image.asset("assets/ad2.png"),
          Image.asset("assets/ad3.jpg"),
          Image.asset("assets/ad4.jpeg"),
          Image.asset("assets/ad5.jpeg"),
        ],
      ),
    );
  }

  BackdropFilter buildDrawer() {
    return BackdropFilter(
      filter: ImageFilter.blur(sigmaX: 9, sigmaY: 9),
      child: Container(
        width: 250,
        color: Colors.transparent.withOpacity(.4),
        child: Column(
          children: <Widget>[
            SizedBox(
              height: 40,
            ),
            SingleChildScrollView(
              child: Column(
                children: <Widget>[
                  buildAdView(),
                  _auth.state == AuthState.SIGNED_IN
                      ? buildfancyButton(
                          "Profile", navigateToProfile, FontAwesomeIcons.user)
                      : buildfancyButton(
                          "Advertise", navigateToQR, FontAwesomeIcons.ad),
                  buildfancyButton(
                      "Scan", navigateToQR, FontAwesomeIcons.qrcode),
                  buildfancyButton(
                      "Settings", navigateToSettings, FontAwesomeIcons.cog),
                  buildfancyButton(
                      "Donate", navigateToQR, FontAwesomeIcons.donate),
                  _auth.state == AuthState.SIGNED_IN
                      ? buildfancyButton("Sign out", signOut, Icons.exit_to_app)
                      : buildfancyButton("Sign In/Register", navigateToSignUp,
                          FontAwesomeIcons.qq),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget buildfancyButton(String label, onPressed, IconData icon) {
    return Column(
      children: <Widget>[
        Container(
          //color: Colors.limeAccent,
          margin: EdgeInsets.only(bottom: 5),
          child: InkWell(
            splashColor: Colors.lime,
            child: ListTile(
              title: Text(
                label,
                style: TextStyle(color: Colors.white),
              ),
              onTap: onPressed,
              trailing: Icon(
                icon,
                color: Colors.white,
              ),
            ),
          ),
        ),
        Divider(
          color: Colors.white,
          height: 1,
        )
      ],
    );
  }

  void navigateToProfile() {
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (context) => Page(
          child: Profile(),
        ),
      ),
    );
  }

  void navigateToInbox() {
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (context) => Inbox()),
    );
  }

  @override
  void dispose() {
    print("disposing");
    super.dispose();
  }
}
