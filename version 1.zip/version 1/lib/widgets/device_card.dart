import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:gsec/models/device.dart';
import 'package:gsec/providers/device_provider.dart';

import 'package:provider/provider.dart';

enum Action { NO, OK }

class DeviceCard extends StatefulWidget {
  final Device device;

  DeviceCard({
    Key key,
    this.device,
  }) : super(key: key);

  @override
  _DeviceCardState createState() => _DeviceCardState();
}

class _DeviceCardState extends State<DeviceCard> {
  DeviceProvider _deviceProvider;

  TextEditingController _ssnController = new TextEditingController();
  TextEditingController _deviceNameController = new TextEditingController();

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _deviceProvider = Provider.of<DeviceProvider>(context);
  }

  bool showEditView = false;

  Future<Action> showConfirmDialog() async {
    return showDialog<Action>(
        context: context,
        builder: (_) {
          return AlertDialog(
            title: Text("Warning"),
            content: Text("Are you sure want to delete ${widget.device.name}"),
            actions: <Widget>[
              FlatButton(
                child: Text("Yes"),
                onPressed: () {
                  Navigator.pop(context, Action.OK);
                },
              ),
              FlatButton(
                child: Text("No"),
                onPressed: () {
                  Navigator.pop(context, Action.NO);
                },
              ),
            ],
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(40),
            ),
          );
        });
  }

  void deleteDevice() async {
    Navigator.pop(context);
    var action = await showConfirmDialog();
    switch (action) {
      case Action.OK:
        _deviceProvider.removeDevice(widget.device);
        break;
      case Action.NO:
        break;
      default:
    }
    //
  }

  Widget _showEditView() {
    _deviceNameController.text = widget.device.name;
    _ssnController.text = widget.device.serialNumber;

    return Column(
      children: <Widget>[
        TextField(
          controller: _ssnController,
        ),
        TextField(
          controller: _deviceNameController,
        ),
        Center(
          child: RaisedButton(
            child: Text("Save Device"), onPressed: () {},
          ),
        )
      ],
    );
  }

  void _showDeviceInfo() {
    showModalBottomSheet(
        context: context,
        builder: (context) {
          return Column(
            children: <Widget>[
              Expanded(
                flex: 1,
                child: buildListHeader(),
              ),
              Expanded(
                flex: 3,
                child: SingleChildScrollView(
                  child: Container(
                    color: Colors.grey.shade200,
                    child: showEditView ? _showEditView() : buildView(),
                  ),
                ),
              ),
            ],
          );
        });
  }

  Column buildView() {
    return Column(
      mainAxisSize: MainAxisSize.max,
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: <Widget>[
        buildListDetail("SSN", widget.device.serialNumber),
        buildListDetail("IMEI 1", widget.device.IMEI1),
        buildListDetail("IMEI 2", widget.device.IMEI2),
        buildListDetail("IMEI 2", widget.device.IMEI2),
      ],
    );
  }

  Container buildListHeader() {
    return Container(
      color: widget.device.color,
      child: Column(
        children: <Widget>[
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Text(
              widget.device.name.toUpperCase(),
              style: TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: <Widget>[
              IconButton(
                icon: Icon(FontAwesomeIcons.exchangeAlt),
                onPressed: () {},
              ),
              IconButton(
                icon: Icon(FontAwesomeIcons.edit),
                onPressed: () {
                  setState(() {
                    Navigator.pop(context);
                    showEditView = !showEditView;
                    _showDeviceInfo();
                  });
                },
              )
            ],
          ),
        ],
      ),
    );
  }

  Padding buildListDetail(String label, String detail) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: <Widget>[
          Text(
            label,
            style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20),
          ),
          Text(
            detail,
            style: TextStyle(fontSize: 15),
          ),
          Divider()
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.all(5),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(10),
        gradient: LinearGradient(
          colors: [
            Colors.white,
            widget.device.color,
          ],
          begin: Alignment.topCenter,
          stops: [
            2.0,
            2.0,
          ],
        ),
      ),
      child: InkWell(
        onTap: _showDeviceInfo,
        child: Center(
          child: SizedBox(
            width: 90,
            child: Text(
              widget.device.name,
              style: TextStyle(
                color: Colors.black,
                fontSize: 20,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ),
      ),
    );
  }
}
