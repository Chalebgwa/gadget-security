import 'package:flutter/material.dart';
import 'package:gsec/page.dart';
import 'package:gsec/views/registration.dart';
import 'package:gsec/views/sign_in.dart';


class Athentication extends StatelessWidget {
  final PageController pageController = new PageController();

  void registerPage() {
    pageController.nextPage(
      curve: Curves.bounceInOut,
      duration: Duration(seconds: 1),
    );
  }

  void loginPage() {
    //pageController.jumpToPage(1);
    pageController.previousPage(
      curve: Curves.bounceInOut,
      duration: Duration(seconds: 1),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Page(
      showDrawer: false,
      child: PageView(
        pageSnapping: true,
        controller: pageController,
        scrollDirection: Axis.horizontal,
        physics: BouncingScrollPhysics(),
        children: <Widget>[
          SignIn(
            onBlueClick: registerPage,
          ),
          Registration(
            onBlueClick: loginPage,
          )
        ],
      ),
    );
  }
}
