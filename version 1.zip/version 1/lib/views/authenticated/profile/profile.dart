import 'dart:io';
import 'dart:math';
import 'dart:ui';

import 'package:flutter/material.dart';

import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:gsec/models/device.dart';
import 'package:gsec/models/user.dart';
import 'package:gsec/providers/auth_providers/auth_providers.dart';
import 'package:gsec/providers/device_provider.dart';
import 'package:gsec/views/authenticated/add_device.dart';
import 'package:gsec/views/authenticated/inbox.dart';
import 'package:gsec/views/commerce/transfer_device.dart';

import 'package:gsec/widgets/device_card.dart';
import 'package:provider/provider.dart';

class Profile extends StatefulWidget {
  @override
  _ProfileState createState() => _ProfileState();
}

class _ProfileState extends State<Profile> {
  static Random random = Random();
  Auth _auth;
  User _currentUser;
  List<Device> _devices;
  DeviceProvider _deviceProvider;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _auth = Provider.of<Auth>(context);
    _currentUser = _auth.currentUser;
    _deviceProvider = Provider.of<DeviceProvider>(context);
    _devices = _deviceProvider.devices;
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return _auth == null ? buildLoading() : buildHomeView(context);
  }

  buildLoading() {
    return Center(child: RefreshProgressIndicator());
  }

  Widget buildHomeView(BuildContext context) {
    return Material(
      type: MaterialType.transparency,
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Container(
          width: MediaQuery.of(context).size.width,
          height: MediaQuery.of(context).size.height,
          padding: EdgeInsets.all(10),
          color: Colors.black.withOpacity(.4),
          child: SingleChildScrollView(
            padding: EdgeInsets.symmetric(horizontal: 10),
            child: Column(
              //mainAxisAlignment: MainAxisAlignment.center,
              //crossAxisAlignment: CrossAxisAlignment.center,
              children: <Widget>[
                Row(
                  children: <Widget>[
                    Expanded(child: buildUserAvatar()),
                    Expanded(
                      child: Text(
                        _currentUser.name + " " + _currentUser.surname,
                        style: TextStyle(fontSize: 30, color: Colors.white),
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 10),

                //SizedBox(height: 3),

                //SizedBox(height: 20),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  mainAxisSize: MainAxisSize.min,
                  children: <Widget>[
                    buildInboxButton(),
                    buildAddButton(context),
                    buildEditProfile(),
                  ],
                ),
                Center(
                  child: _devices.length <= 0 //_devices.isEmpty
                      ? Text(
                          "No registered devices",
                          style: TextStyle(
                            color: Colors.white,
                          ),
                        )
                      : GridView.builder(
                          shrinkWrap: true,
                          physics: NeverScrollableScrollPhysics(),
                          primary: false,
                          padding: EdgeInsets.all(5),
                          itemCount: _devices.length, //_devices.length,
                          gridDelegate:
                              SliverGridDelegateWithFixedCrossAxisCount(
                            crossAxisCount: 2,
                          ),
                          itemBuilder: (BuildContext context, int index) {
                            return new DeviceCard(
                              device: _devices[index],
                            );
                          },
                        ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Container buildEditProfile() {
    return Container(
      margin: EdgeInsets.all(10),
      child: RaisedButton(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(30),
        ),
        child: Icon(
          FontAwesomeIcons.userEdit,
        ),
        onPressed: () {
          Navigator.pushNamed(context, "/editProfile");
        },
      ),
    );
  }

  RaisedButton buildAddButton(BuildContext context) {
    return RaisedButton(
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(20),
      ),
      child: Icon(
        Icons.add,
        color: Colors.black,
      ),
      color: Colors.white,
      onPressed: () {
        Navigator.push(
          context,
          MaterialPageRoute(builder: (BuildContext context) {
            return AddDevice();
          }),
        );
      },
    );
  }

  Stack buildInboxButton() {
    return Stack(
      children: <Widget>[
        Container(
          margin: EdgeInsets.all(10),
          child: RaisedButton(
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(20),
            ),
            child: Icon(
              FontAwesomeIcons.exchangeAlt,
              color: Colors.black,
            ),
            color: Colors.grey.shade200,
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => TransferView(),
                ),
              );
            },
          ),
        ),
        Positioned(
          right: 2,
          top: 9,
          child: CircleAvatar(
            backgroundColor: Colors.blue,
            child: Text(
              "34",
              style: TextStyle(color: Colors.white),
            ),
            radius: 15,
          ),
        ),
      ],
    );
  }

  Stack buildUserAvatar() {
    return Stack(
      children: <Widget>[
        CircleAvatar(
          backgroundColor: Colors.red,
          radius: 50,
          child: CircleAvatar(
            backgroundImage: _currentUser.imageUrl == null
                ? AssetImage("assets/cm4.jpeg")
                : FileImage(
                    File(_currentUser.imageUrl),
                  ),
            radius: 45,
          ),
        ),
      ],
    );
  }
}
