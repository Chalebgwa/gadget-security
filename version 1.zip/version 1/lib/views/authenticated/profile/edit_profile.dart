import 'dart:io';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import 'dart:ui';

import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:gsec/models/user.dart';
import 'package:gsec/page.dart';
import 'package:gsec/providers/auth_providers/auth_providers.dart';
import 'package:gsec/providers/device_provider.dart';
import 'package:image_picker/image_picker.dart';

import 'package:provider/provider.dart';

class EditProfile extends StatefulWidget {
  final Auth auth;
  final VoidCallback onBlueClick;

  EditProfile({Key key, this.auth, this.onBlueClick}) : super(key: key);

  @override
  _EditProfileState createState() => _EditProfileState();
}

class _EditProfileState extends State<EditProfile> {
  File image;
  Auth _auth;
  User _currentUser;
  DeviceProvider _deviceProvider;

  TextEditingController _nameController = new TextEditingController();
  TextEditingController _surnameController = new TextEditingController();
  TextEditingController _middlenameController = new TextEditingController();
  TextEditingController _idController = new TextEditingController();
  TextEditingController _emailController = new TextEditingController();
  TextEditingController _phoneController = new TextEditingController();
  TextEditingController _cityController = new TextEditingController();
  TextEditingController _countryController = new TextEditingController();

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _auth = Provider.of<Auth>(context);
    _currentUser = _auth.currentUser;
    _deviceProvider = Provider.of<DeviceProvider>(context);

    _nameController.text = _currentUser.name;
    _surnameController.text = _currentUser.surname;

    _middlenameController.text = _currentUser.middlename;
    _idController.text = _currentUser.idNumber;

    _emailController.text = _currentUser.email;
    _phoneController.text = _currentUser.phone;

    _cityController.text = _currentUser.city;
    _countryController.text = _currentUser.country;
  }

  void pickImage() async {
    image = await ImagePicker.pickImage(source: ImageSource.gallery);
    setState(() {});
  }

  void save() {
    var _name = _nameController.text;
    var _surname = _phoneController.text;
    var _middleName = _middlenameController.text;
    //var _userID = _
    var _id = _idController.text;
    var _phone = _phoneController.text;
    var _email = _emailController.text;
    var _city = _cityController.text;
    var _country = _countryController.text;
    var _imageUrl = image.path ?? _currentUser.imageUrl;

    _auth.updateUser(
        city: _city,
        country: _country,
        email: _email,
        idNumber: _id,
        phone: _phone,
        userId: "4",
        middlename: _middleName,
        name: _name,
        surname: _surname,
        imageUrl: _imageUrl);
  }

  @override
  Widget build(BuildContext context) {
    return Page(
      child: ListView(
        padding: EdgeInsets.all(20),
        children: <Widget>[
          Container(
            margin: EdgeInsets.all(20),
            width: double.infinity,
            alignment: Alignment.center,
            child: CircleAvatar(
              radius: 55,
              backgroundColor: Colors.red,
              child: CircleAvatar(
                backgroundColor: Colors.red,
                backgroundImage: _currentUser.imageUrl == null
                    ? AssetImage("assets/cm4.jpeg")
                    : FileImage(
                        File(_currentUser.imageUrl),
                      ),
                radius: 50,
                child: IconButton(
                  icon: Icon(
                    FontAwesomeIcons.pen,
                  ),
                  onPressed: pickImage,
                ),
              ),
            ),
          ),
          buildUserDetailsCard(),
          buildContantDetailsCard(),
          buildLocationDetailsCard(),
          RaisedButton(
            onPressed: save,
            child: Text("Save"),
          ),
        ],
      ),
    );
  }

  Widget buildUserDetailsCard() {
    return ListBody(
      children: <Widget>[
        Container(
          color: Colors.white,
          child: ListTileTheme(
            style: ListTileStyle.list,
            child: ListTile(
              title: Text("User Details"),
            ),
          ),
        ),
        Column(
          children: <Widget>[
            buildTextField("name", _nameController),
            buildTextField("surname", _surnameController),
            buildTextField("middle name", _middlenameController),
            buildTextField("id number", _idController),
          ],
        ),
        Divider(
          height: 30,
        )
      ],
    );
  }

  Widget buildLocationDetailsCard() {
    return ListBody(
      children: <Widget>[
        Container(
          color: Colors.white,
          child: ListTileTheme(
            style: ListTileStyle.list,
            child: ListTile(
              title: Text("Location"),
            ),
          ),
        ),
        Column(
          children: <Widget>[
            buildTextField("city", _cityController),
            buildTextField("country", _countryController),
          ],
        ),
        Divider(
          height: 30,
        )
      ],
    );
  }

  Widget buildContantDetailsCard() {
    return ListBody(
      children: <Widget>[
        Container(
          color: Colors.white,
          child: ListTileTheme(
            style: ListTileStyle.list,
            child: ListTile(
              title: Text("Contacts"),
            ),
          ),
        ),
        Column(
          children: <Widget>[
            buildTextField("email", _emailController),
            buildTextField("phone", _phoneController),
          ],
        ),
        Divider(
          height: 30,
        )
      ],
    );
  }

  Widget buildTextField(label, controller) {
    return Container(
      color: Colors.black.withOpacity(.5),
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: TextField(
          controller: controller,
          style: TextStyle(
            color: Colors.white,
          ),
          decoration: InputDecoration(
            labelStyle: TextStyle(color: Colors.white),
            enabledBorder: UnderlineInputBorder(
              borderSide: BorderSide(
                color: Colors.white,
              ),
            ),
            hintText: "Enter your" + label,
            labelText: label,
          ),
        ),
      ),
    );
  }
}
