import 'dart:ui';

import 'package:flutter/material.dart';

import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:gsec/models/device.dart';
import 'package:gsec/page.dart';
import 'package:gsec/providers/device_provider.dart';
import 'package:provider/provider.dart';

class AddDevice extends StatefulWidget {
  final DeviceProvider deviceProvider;

  AddDevice({Key key, this.deviceProvider}) : super(key: key);

  @override
  _AddDeviceState createState() => _AddDeviceState();
}

class _AddDeviceState extends State<AddDevice> {
  final TextEditingController nameController = new TextEditingController();

  final TextEditingController ssnController = new TextEditingController();

  final TextEditingController imei1Controller = new TextEditingController();

  final TextEditingController imei2Controller = new TextEditingController();

  Color _selectedColor;
  DeviceProvider _deviceProvider;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _deviceProvider = Provider.of<DeviceProvider>(context);
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: Colors.transparent,
        body: Page(
          child: Container(
            margin: EdgeInsets.only(left: 30, right: 30, bottom: 10),
            child: BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 9, sigmaY: 9),
              child: Container(
                color: Colors.black.withOpacity(.5),
                child: SingleChildScrollView(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      CircleAvatar(
                        radius: 20,
                        child: Icon(
                          FontAwesomeIcons.user,
                          color: Colors.blue,
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Text(
                          "ADD DEVICE",
                          style: TextStyle(
                              color: Colors.white,
                              fontSize: 15,
                              fontWeight: FontWeight.bold),
                        ),
                      ),
                      buildTextField("product name", nameController),
                      buildTextField("Serial number", ssnController),
                      buildTextField("IMEI 1", imei1Controller),
                      buildTextField("IMEI 2", imei2Controller),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: <Widget>[
                          buildYearDropDown(),
                          buildColorButton(),
                        ],
                      ),
                      buildConfirmButton(context),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  DropdownButton buildYearDropDown() {
    return DropdownButton(
      items: <DropdownMenuItem>[],
      onChanged: (value) {},
      hint: Text(
        "Year",
        style: TextStyle(
          color: Colors.white,
        ),
      ),
    );
  }

  DropdownButton buildColorButton() {
    return DropdownButton<Color>(
      value: _selectedColor,
      items: <DropdownMenuItem<Color>>[
        DropdownMenuItem(
          child: Text("Red"),
          value: Colors.red,
        ),
        DropdownMenuItem(
          child: Text("Yellow"),
          value: Colors.yellow,
        ),
        DropdownMenuItem(
          child: Text("Blue"),
          value: Colors.blue,
        ),
        DropdownMenuItem(
          child: Text("Green"),
          value: Colors.green,
        ),
        DropdownMenuItem(
          child: Text("Purple"),
          value: Colors.purple,
        ),
        DropdownMenuItem(
          child: Text("Orange"),
          value: Colors.orange,
        ),
        DropdownMenuItem(
          child: Text("Pink"),
          value: Colors.pink,
        ),
        DropdownMenuItem(
          child: Text("Lime"),
          value: Colors.lime,
        ),
        DropdownMenuItem(
          child: Text("Pink"),
          value: Colors.pink,
        ),
        DropdownMenuItem(
          child: Text("Black"),
          value: Colors.black,
        ),
        DropdownMenuItem(
          child: Text("White"),
          value: Colors.white,
        ),
        DropdownMenuItem(
          child: Text("Grey"),
          value: Colors.grey,
        ),
        DropdownMenuItem(
          child: Text("Brown"),
          value: Colors.brown,
        ),
      ],
      onChanged: (Color value) {
        setState(() {
          _selectedColor = value;
        });
      },
      hint: Text(
        "Color",
        style: TextStyle(
          color: Colors.white,
        ),
      ),
    );
  }

  Container buildConfirmButton(context) {
    return Container(
      margin: EdgeInsets.all(20),
      child: RaisedButton(
        color: Colors.blue,
        child: Container(
          width: double.infinity,
          child: Center(child: Text("Confirm")),
        ),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
        onPressed: () {
          Device device = Device(
            
            color: _selectedColor,
            IMEI1: imei1Controller.text,
            IMEI2: imei2Controller.text,
            name: nameController.text,
            serialNumber: ssnController.text,
            year: DateTime.now(),
          );

          _deviceProvider.addDevice(device);
          Navigator.pop(context);
        },
      ),
    );
  }

  Padding buildTextField(label, controller) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: TextField(
        controller: controller,
        style: TextStyle(
          color: Colors.white,
        ),
        decoration: InputDecoration(
          labelStyle: TextStyle(color: Colors.white),
          enabledBorder: UnderlineInputBorder(
            borderSide: BorderSide(
              color: Colors.white,
            ),
          ),
          hintText: "Enter your" + label,
          labelText: label,
        ),
      ),
    );
  }
}
