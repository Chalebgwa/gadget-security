import 'package:flutter/material.dart';
import 'package:gsec/page.dart';

class Settings extends StatelessWidget {
  const Settings({Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Page(
      child: ListView(
        children: <Widget>[
          buildSettingsCard("Security"),
          buildSettingsCard("Gestures"),
          buildSettingsCard("Personal info"),
        ],
      ),
    );
  }

  Widget buildSettingsCard(label) {
    var detailStyle = TextStyle(color: Colors.white);

    return ListBody(
      children: <Widget>[
        Container(
          color: Colors.white,
          child: ListTileTheme(
            style: ListTileStyle.list,
            child: ListTile(
              title: Text(label),
            ),
          ),
        ),
        Container(
          color: Colors.black.withOpacity(.5),
          child: Column(
            children: <Widget>[
              buildListItem("",detailStyle),
              buildListItem("",detailStyle),
              buildListItem("",detailStyle),
            ],
          ),
        ),
        Divider(
          height: 30,
        )
      ],
    );
  }

  ListTile buildListItem(label,TextStyle detailStyle) {
    return ListTile(
      title: Text(
        label,
        style: detailStyle,
      ),
    );
  }



  
}
