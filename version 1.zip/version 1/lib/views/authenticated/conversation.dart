import 'package:flutter/material.dart';
import 'package:gsec/page.dart';
import 'package:gsec/providers/chat_provider.dart';

class ConversationView extends StatefulWidget {
  final InboxProvider inboxProvider;
  final String groupChatId;

  const ConversationView({
    Key key,
    this.inboxProvider,
    this.groupChatId,
  }) : super(key: key);

  @override
  _ConversationViewState createState() => _ConversationViewState();
}

class _ConversationViewState extends State<ConversationView> {


  

  @override
  Widget build(BuildContext context) {
    return Page(
      child: Scaffold(
        floatingActionButton: FloatingActionButton(
          onPressed: () {
            widget.inboxProvider.fetchConvoById(widget.groupChatId);
          },
        ),
        body: ListView.builder(
          itemBuilder: (BuildContext context, int index) {
            return ListTile(
              title: Text("$index"),
            );
          },
        ),
      ),
    );
  }
}
