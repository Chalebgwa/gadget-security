import 'package:flutter/material.dart';
import 'package:gsec/page.dart';
import 'package:gsec/providers/device_provider.dart';
import 'package:gsec/providers/user_provider.dart';
import 'package:provider/provider.dart';

class TransferView extends StatelessWidget {
  const TransferView({Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    
    DeviceProvider _deviceProvider = Provider.of<DeviceProvider>(context);
    UserProvider _userProvider = Provider.of<UserProvider>(context);

    

    return Page(
      child: Container(),
    );
  }
}
