import 'package:flutter/material.dart';
import 'package:gsec/page.dart';

class Advertise extends StatelessWidget {
  const Advertise({Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Page(
      child: Column(
        children: <Widget>[
          
        ],
      ),
    );
  }
}
