import 'package:flutter/material.dart';
import 'package:gsec/page.dart';
import 'package:gsec/views/qr_athentication/camera.dart';
import 'package:gsec/views/qr_athentication/qr.dart';
import 'package:gsec/views/user_info.dart';


class Scanner extends StatelessWidget {
  final PageController pageController = new PageController();


  void navigateToUserInfo(String serial, BuildContext context) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => UserInfo(),
      ),
    );
  }


  void ScannerPage() {
    pageController.nextPage(
      curve: Curves.bounceInOut,
      duration: Duration(seconds: 1),
    );
  }

  void QRPage() {
    //pageController.jumpToPage(1);
    pageController.previousPage(
      curve: Curves.bounceInOut,
      duration: Duration(seconds: 1),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Page(
      showDrawer: false,
      child: PageView(
        pageSnapping: true,
        controller: pageController,
        scrollDirection: Axis.horizontal,
        physics: BouncingScrollPhysics(),
        children: <Widget>[
          QR(),
          CameraView(
            onScanComplete: navigateToUserInfo,
          )
        ],
      ),
    );
  }
}
