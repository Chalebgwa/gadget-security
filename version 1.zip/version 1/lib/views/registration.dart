import 'dart:ui';

import 'package:device_info/device_info.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:gsec/providers/auth_providers/auth_providers.dart';
import 'package:gsec/providers/device_provider.dart';
import 'package:gsec/providers/user_provider.dart';
import 'package:provider/provider.dart';

class Registration extends StatefulWidget {
  final Auth auth;
  final VoidCallback onBlueClick;

  Registration({Key key, this.auth, this.onBlueClick}) : super(key: key);

  @override
  _RegistrationState createState() => _RegistrationState();
}

class _RegistrationState extends State<Registration> {
  bool _isFirstDevice = false;

  String _deviceSSN;
  String _deviceName;
  AndroidDeviceInfo _deviceInfo;

  final TextEditingController _nameController = new TextEditingController();

  final TextEditingController _surnameController = new TextEditingController();

  final TextEditingController _emailController = new TextEditingController();

  final TextEditingController _passwordController = new TextEditingController();

  final TextEditingController _phoneController = new TextEditingController();

  final TextEditingController _idController = new TextEditingController();

  final TextEditingController _imeiController = new TextEditingController();

  DeviceProvider _deviceProvider;
  UserProvider _userProvider;
  Auth _auth;

  @override
  void initState() {
    super.initState();
    init();
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _deviceProvider = Provider.of<DeviceProvider>(context);
    _userProvider = Provider.of<UserProvider>(context);
    _auth = Provider.of<Auth>(context);
  }

  void init() async {
    var deviceInfoPlugin = DeviceInfoPlugin();
    _deviceInfo = await deviceInfoPlugin.androidInfo;
    _deviceSSN = _deviceInfo.androidId;
    _deviceName = _deviceInfo.model;
  }


  showWelcomcePopUp(){

  }

  void register() async {
    var _name = _nameController.text;
    var _surname = _surnameController.text;
    var _email = _emailController.text;
    var _password = _passwordController.text;
    var _id = _idController.text;

    if (_deviceProvider != null && _userProvider != null) {
      bool _success =
          await _auth.register(_name, _surname, _id, _email, _password);
      if (_isFirstDevice) {
        _deviceProvider.setPrimaryDevice(_deviceInfo,_id);
      }

      if(_success){
        Navigator.pop(context);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.only(left: 20, right: 20),
      color: Colors.black.withOpacity(.5),
      child: SingleChildScrollView(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            buildHeader(),
            buildTextField("name", _nameController),
            buildTextField("gorvernment issued id", _idController),
            buildTextField("surname", _surnameController),
            buildTextField("email", _emailController),
            buildTextField("password", _passwordController),
            buildDeviceInfo(),
            buildSignUpButton(),
          ],
        ),
      ),
    );
  }

  Row buildHeader() {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.center,
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      children: <Widget>[
        Expanded(
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: FloatingActionButton(
              child: Icon(
                FontAwesomeIcons.solidArrowAltCircleLeft,
                color: Colors.blue,
              ),
              onPressed: widget.onBlueClick,
              backgroundColor: Colors.black,
            ),
          ),
        ),
        Expanded(
          flex: 3,
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: Text(
              "Registration",
              style: TextStyle(color: Colors.blue.shade100, fontSize: 30),
            ),
          ),
        ),
      ],
    );
  }

  Row buildDeviceInfo() {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: <Widget>[
        Expanded(
            flex: 2,
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Text(
                _deviceName ?? "Device Name",
                style: TextStyle(color: Colors.white),
              ),
            )),
        Expanded(
          flex: 2,
          child: Card(
            color: Colors.transparent,
            child: CheckboxListTile(
              title: Text(
                "save device",
                style: TextStyle(
                  fontSize: 10,
                  color: Colors.white,
                ),
              ),
              //tristate: false,
              activeColor: Colors.blue,
              selected: true,
              //checkColor: Colors.white,
              value: _isFirstDevice,
              onChanged: (bool value) {
                setState(() {
                  _isFirstDevice = value;
                });
                if (value) {
                  _imeiController.text = _deviceName;
                } else {
                  _imeiController.clear();
                }
              },
            ),
          ),
        )
      ],
    );
  }

  Container buildSignUpButton() {
    return Container(
      margin: EdgeInsets.all(20),
      child: RaisedButton(
        color: Colors.blue,
        child: Container(
          width: double.infinity,
          child: Center(child: Text("Sign up")),
        ),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
        onPressed: register,
      ),
    );
  }

  Padding buildTextField(label, controller) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: TextField(
        controller: controller,
        style: TextStyle(
          color: Colors.white,
        ),
        decoration: InputDecoration(
          
          labelStyle: TextStyle(color: Colors.white),
          enabledBorder: UnderlineInputBorder(
            borderSide: BorderSide(
              color: Colors.white,
            ),
          ),
          hintText: "Enter your" + label,
          labelText: label,
        ),
      ),
    );
  }
}
