import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_signin_button/flutter_signin_button.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:gsec/providers/auth_providers/auth_providers.dart';
import 'package:provider/provider.dart';

class SignIn extends StatelessWidget {
  final VoidCallback onBlueClick;

  const SignIn({Key key, this.onBlueClick}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    Auth _auth = Provider.of<Auth>(context);

    return Container(
      margin: EdgeInsets.only(left: 20, right: 20, bottom: 20),
      color: Colors.black.withOpacity(.5),
      child: SingleChildScrollView(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: <Widget>[
                Expanded(
                    flex: 5,
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Text(
                        "Login",
                        style: TextStyle(
                            color: Colors.blue.shade100, fontSize: 30),
                      ),
                    )),
                Expanded(
                  flex: 2,
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: FloatingActionButton(
                      child: Icon(
                        FontAwesomeIcons.solidArrowAltCircleRight,
                        color: Colors.blue,
                      ),
                      onPressed: onBlueClick,
                      backgroundColor: Colors.black,
                    ),
                  ),
                )
              ],
            ),
            buildTextField("email"),
            buildTextField("password"),
            buildLoginButton(context, _auth),
            buildForgotpassword()
          ],
        ),
      ),
    );
  }

  FlatButton buildForgotpassword() {
    return FlatButton(
      child: Text(
        "forgot password",
        style: TextStyle(
          color: Colors.white,
        ),
      ),
      onPressed: () {},
    );
  }

  Container buildLoginButton(BuildContext context, Auth _auth) {
    return Container(
      margin: EdgeInsets.all(20),
      child: SignInButton(
        Buttons.Google,
        onPressed: () {
          Navigator.pop(context);

          _auth.signInWithGoogle().then((s) {
            _auth.signIn();
          });
        },
      ),
    );
  }

  Padding buildTextField(label) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: TextField(
        style: TextStyle(
          color: Colors.white,
        ),
        decoration: InputDecoration(
          labelStyle: TextStyle(color: Colors.white),
          enabledBorder: UnderlineInputBorder(
            borderSide: BorderSide(
              color: Colors.white,
            ),
          ),
          hintText: "Enter your" + label,
          labelText: label,
        ),
      ),
    );
  }
}
