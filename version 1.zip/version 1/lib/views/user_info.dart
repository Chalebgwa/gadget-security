import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:gsec/models/user.dart';
import 'package:gsec/page.dart';
import 'package:url_launcher/url_launcher.dart';

class UserInfo extends StatelessWidget {
  UserInfo({Key key, this.user}) : super(key: key);

  final User user;

  var detailStyle = TextStyle(
    color: Colors.white,
    fontWeight: FontWeight.bold,
  );

  void call() {
    launch("tel:74000300");
  }

  @override
  Widget build(BuildContext context) {
    return Page(
      child: Scaffold(
        backgroundColor: Colors.transparent,
        floatingActionButton: FloatingActionButton(
          child: Icon(FontAwesomeIcons.phone),
          onPressed: call,
        ),
        body: Column(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            Expanded(
              flex: 1,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  Container(
                    color: Colors.transparent,
                    alignment: Alignment.center,
                    child: CircleAvatar(
                      radius: 50,
                      backgroundImage: AssetImage(
                        "assets/cm2.jpeg",
                      ),
                    ),
                  ),
                  Text(
                    "Test Pilot",
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 40,
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              flex: 2,
              child: Container(
                margin: EdgeInsets.all(20),
                color: Colors.white,
                child: Column(
                  children: <Widget>[
                    Container(
                      color: Colors.blue,
                      child: ListTile(
                        leading: Icon(
                          FontAwesomeIcons.coins,
                          color: Colors.white,
                        ),
                        title: Text(
                          "Contact details",
                          style: detailStyle,
                        ),
                      ),
                    ),
                    ListBody(
                      children: <Widget>[
                        Container(
                          color: Colors.white,
                          child: ListTile(
                            leading: Icon(FontAwesomeIcons.phone),
                            title: Text("+267 77147912"),
                          ),
                        ),
                        Container(
                          color: Colors.white,
                          child: ListTile(
                            leading: Icon(Icons.email),
                            title: Text("testpilot@gmail.com"),
                          ),
                        ),
                        Container(
                          color: Colors.white,
                          child: ListTile(
                            leading: Icon(FontAwesomeIcons.city),
                            title: Text("Francistown"),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class CallsAndMessagesService {
  void call(String number) => launch("tel://$number");

  void sendSms(String number) => launch("sms:$number");

  void sendEmail(String email) => launch("mailto:$email");
}
