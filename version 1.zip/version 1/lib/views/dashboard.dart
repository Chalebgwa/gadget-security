import 'dart:ui';

import 'package:carousel_pro/carousel_pro.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';
import 'package:gsec/page.dart';
import 'package:gsec/providers/auth_providers/auth_providers.dart';
import 'package:gsec/views/authenticated/profile/profile.dart';
import 'package:gsec/views/authentication/authentication.dart';
import 'package:gsec/views/user_info.dart';
import 'package:gsec/widgets/fancy_search.dart';
import 'package:provider/provider.dart';

class DashBoard extends StatefulWidget {
  @override
  _DashBoardState createState() => _DashBoardState();
}

class _DashBoardState extends State<DashBoard> {
  final TextEditingController nameController = new TextEditingController();
  final FocusNode _focusNode = new FocusNode();
  final ScrollController _scrollController = new ScrollController();
  bool _showFAB = true;

  Auth _auth;

  void onChangeFocus() {
    if (_focusNode.hasFocus) {
      setState(() {
        _showFAB = false;
      });
    } else {
      setState(() {
        _showFAB = true;
      });
    }
  }

  @override
  void initState() {
    super.initState();
    _focusNode.addListener(onChangeFocus);
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _auth = Provider.of<Auth>(context);
  }

  void signOut() {
    _auth.signOut();
  }

  void navigateToSignUp() {
    Navigator.pop(context);
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => Athentication(),
      ),
    );
  }

  void navigateToProfile() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => Page(
          child: Profile(),
        ),
      ),
    );
  }

  void searchBySerial(String ssn) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => UserInfo(),
      ),
    );
  }

  SizedBox buildAdView() {
    return SizedBox(
      height: 200,
      //width: double.infinity,
      child: Carousel(
        autoplayDuration: Duration(seconds: 5),
        noRadiusForIndicator: true,
        overlayShadow: false,
        showIndicator: false,
        animationCurve: Curves.easeOutBack,
        images: [
          Image.asset("assets/ad1.jpeg"),
          Image.asset("assets/ad2.png"),
          Image.asset("assets/ad3.jpg"),
          Image.asset("assets/ad4.jpeg"),
          Image.asset("assets/ad5.jpeg"),
        ],
      ),
    );
  }

  List<Widget> buildAds() {
    Size size = MediaQuery.of(context).size;

    var images = [
      "assets/ad1.jpeg",
      "assets/ad2.png",
      "assets/ad3.jpg",
      "assets/ad4.jpeg",
      "assets/ad5.jpeg"
    ];

    return List<Widget>.generate(images.length, (int i) {
      return Container(
        width: size.width,
        height: size.height / 2,
        decoration: BoxDecoration(
          image:
              DecorationImage(image: AssetImage(images[i]), fit: BoxFit.fill),
        ),
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      floatingActionButton: FancySearch(
        onPressed: searchBySerial,
      ),
      body: SingleChildScrollView(
        controller: _scrollController,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            //buildCarouselSlider(),
            Container(
              margin: EdgeInsets.all(30),
              height: 90,
              width: 90,
              child: _auth.state == AuthState.SIGNED_IN
                  ? buildUserAvatar()
                  : Container(),
            ),

            //buildAdButton(),
            // buildAdView()
          ],
        ),
      ),
    );
  }

  CarouselSlider buildCarouselSlider() {
    return CarouselSlider(
            autoPlay: true,
            //aspectRatio: 10 / 4,
            viewportFraction: 1.0,
            enlargeCenterPage: true,
            autoPlayCurve: Curves.decelerate,
            pauseAutoPlayOnTouch: Duration(seconds: 3),
            items: buildAds(),
          );
  }

  Widget buildUserAvatar() {
    return InkWell(
      onTap: navigateToProfile,
      child: CircleAvatar(
        backgroundImage: AssetImage("assets/cm7.jpeg"),
      ),
    );
  }

  Image buildLogo() {
    return Image.asset(
      "assets/logo.png",
    );
  }

  void navigateToQR() {
    Navigator.push(
      context,
      MaterialPageRoute(
          //builder: (_) => DeviceInfo(),
          ),
    );
  }
}
